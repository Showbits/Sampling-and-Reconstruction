To run the python file write the following command : 

python Lal_22111027_Assignment4

Then enter sampling percentage out of {1, 3, 5}
then enter method out of ('linear' and 'nearest')